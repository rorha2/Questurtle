// 🐢 JavaScript 한 줄 주석

/* 
JavaScript 여러 줄 주석
*/


// =====================
// 초기 실행
// =====================

const isLoggedIn =
checkLogin();

if(isLoggedIn){

    startApp();

}


// =====================
// 앱 데이터 시작
// =====================

function startApp(){

    loadCurrentUserData();

    loadQuests();

    updatePoint();

    updateHistory();

    checkAttendance();

    resetDailyQuests();

    updateQuest();

    updateShop();

}


// =====================
// 로그인
// =====================

loginButton.addEventListener(
"click",
function(){

    const success =
    login();

    if(success){

        startApp();

    }

});

// 엔터키 로그인
loginPasswordInput.addEventListener(
"keydown",
function(event){

    if(event.key !== "Enter"){
        return;
    }

    const success =
    login();

    if(success){

        startApp();

    }

});

// =====================
// 로그아웃
// =====================

logoutButton.addEventListener(
"click",
function(){

    logout();

});


// =====================
// 일일 퀘스트 초기화
// =====================

function resetDailyQuests(){

    const today =
    new Date().toLocaleDateString("sv-SE");

    if(lastQuestReset === today){
        return;
    }

    quests.forEach(function(quest){

        if(quest.type === "daily"){

            quest.completed = false;

        }

    });

    saveQuests();

    lastQuestReset = today;

    currentUser.lastQuestReset =
    lastQuestReset;

    saveUsers();

}


// =====================
// 출석 보상
// =====================

function checkAttendance(){

    const today =
    new Date().toLocaleDateString("sv-SE");

    if(lastAttendance === today){
        return;
    }

    givePoint(100, "출석 보상");

    lastAttendance = today;

    currentUser.lastAttendance =
    lastAttendance;

    saveUsers();

}


// =====================
// 로고 → 홈
// =====================

homeLogoButton.addEventListener(
    "click",
    function(){

        hideAll();

        homeScreen.style.display =
        "block";

    }
);


// =====================
// 홈 → 포인트
// =====================

pointCard.addEventListener("click",function(){

    hideAll();

    pointScreen.style.display="block";

});


// =====================
// 뒤로가기
// =====================

document
.querySelectorAll(".back-button")
.forEach(function(button){

    button.addEventListener("click",function(){

        hideAll();

        homeScreen.style.display="block";

    });

});


// =====================
// 포인트 적립
// =====================

addPointButton.addEventListener("click",function(){

    let amount =
    Number(pointInput.value);

        if(amount <= 0){
        return;
        }

    givePoint(amount, "직접 적립");

    pointInput.value = "";

});


// =====================
// 포인트 사용
// =====================

usePointButton.addEventListener("click",function(){

    let amount =
    Number(pointInput.value);

        if(amount <= 0){
        return;
        }

    const success =
        usePoint(amount, "직접 사용");

        if(success){
            pointInput.value = "";
        }

});


// =====================
// 퀘스트
// =====================

questButton.addEventListener("click",function(){

    hideAll();

    questScreen.style.display="block";

});


// =====================
// 상점
// =====================

shopButton.addEventListener("click",function(){

    hideAll();

    shopScreen.style.display="block";

});


// =====================
// 가방
// =====================

bagButton.addEventListener("click",function(){

    hideAll();

    updateBag();

    bagScreen.style.display = "block";

});


// =====================
// 설정
// =====================

settingsButton.addEventListener("click", () => {

    hideAll();

    settingsScreen.style.display = "block";

});

soundButton.addEventListener("click", () => {

    alert("효과음 설정은 준비 중입니다.");

});

musicButton.addEventListener("click", () => {

    alert("배경음 설정은 준비 중입니다.");

});

themeButton.addEventListener("click", () => {

    alert("테마 기능은 준비 중입니다.");

});

adminButton.addEventListener("click", () => {

    hideAll();

    adminScreen.style.display = "block";

});

adminLoginButton.addEventListener("click", () => {

    alert("다음 단계에서 비밀번호 기능을 만들 예정입니다.");

});


// =====================
// 프로필 수정
// =====================

let selectedProfileIcon = "";

function updateProfileIconPreview(){

    profileIconPreview.textContent =
    selectedProfileIcon;

    profileIconOptions.forEach(
        function(option){

            const isSelected =
            option.dataset.icon ===
            selectedProfileIcon;

            option.classList.toggle(
                "is-selected",
                isSelected
            );

            option.setAttribute(
                "aria-pressed",
                String(isSelected)
            );

        }
    );

}

function openProfileIconModal(){

    updateProfileIconPreview();

    profileIconModal.style.display =
    "flex";

    profileIconModal.setAttribute(
        "aria-hidden",
        "false"
    );

}

function closeProfileIconModal(){

    profileIconModal.style.display =
    "none";

    profileIconModal.setAttribute(
        "aria-hidden",
        "true"
    );

}

function openProfileEditScreen(){

    if(
        !currentUser ||
        currentUser.role !== "user"
    ){
        return;
    }

    profileNicknameInput.value =
    currentUser.nickname;

    profileTurtleNameInput.value =
    currentUser.turtle.name;

    selectedProfileIcon =
    currentUser.profileIcon ||
    currentUser.profileEmoji ||
    "❤️";

    updateProfileIconPreview();

    hideAll();

    profileEditScreen.style.display =
    "block";

}

function closeProfileEditScreen(){

    closeProfileIconModal();

    hideAll();

    settingsScreen.style.display =
    "block";

}

profileEditButton.addEventListener(
    "click",
    openProfileEditScreen
);

profileEditBackButton.addEventListener(
    "click",
    closeProfileEditScreen
);

profileEditCancelButton.addEventListener(
    "click",
    closeProfileEditScreen
);

profileEditSaveButton.addEventListener(
    "click",
    function(){

        const success =
        changeCurrentUserProfile(
            profileNicknameInput.value,
            profileTurtleNameInput.value,
            selectedProfileIcon
        );

        if(!success){

            alert(
                "사용자명과 거북이 이름을 모두 입력해주세요."
            );

            return;

        }

        alert("프로필이 저장되었어요.");

        closeProfileEditScreen();

    }
);

profileIconButton.addEventListener(
    "click",
    openProfileIconModal
);

profileIconOptions.forEach(
    function(option){

        option.addEventListener(
            "click",
            function(){

                selectedProfileIcon =
                option.dataset.icon;

                updateProfileIconPreview();

                closeProfileIconModal();

            }
        );

    }
);

profileIconModal.addEventListener(
    "click",
    function(event){

        if(event.target === profileIconModal){

            closeProfileIconModal();

        }

    }
);

document.addEventListener(
    "keydown",
    function(event){

        if(
            event.key === "Escape" &&
            profileIconModal.style.display ===
            "flex"
        ){

            closeProfileIconModal();

        }

    }
);


// localStorage.clear();